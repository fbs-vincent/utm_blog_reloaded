<?php get_header(); ?>
<div class="container">
    <div class="page-not-found">
    <h2>404 <span>Page not found</span></h2>
    <a href="<?php echo site_url('/home'); ?>">Return to home</a>
    </div>

</div>
<?php get_footer(); ?>
<?php get_header() ?>
<h1>Welcome to the pages page</h1>
<?php get_footer() ?>
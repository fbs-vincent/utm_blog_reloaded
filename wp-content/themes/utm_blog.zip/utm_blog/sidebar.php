<div id="sidebar" class="widget-area">
    <?php dynamic_sidebar('sidebar-widget') ?>
</div>